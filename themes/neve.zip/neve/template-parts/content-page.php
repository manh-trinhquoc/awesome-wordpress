<?php
/**
 * Author:          Andrei Baicus <andrei@themeisle.com>
 * Created on:      23/08/2018
 *
 * @package Neve
 */

do_action( 'neve_do_single_page' );

