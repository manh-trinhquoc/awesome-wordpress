<?php

class WPML_TP_Batch_Exception extends WPML_TP_Exception {

}
