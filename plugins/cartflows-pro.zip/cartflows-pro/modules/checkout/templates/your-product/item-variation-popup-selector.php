<?php
/**
 * Variation popup selector
 *
 * @package cartflows
 */

?>

<div class="wcf-item-choose-options"><a href="#" data-product="<?php echo $parent_id; ?>" data-variation="<?php echo $rc_product_id; ?>">
	<?php echo $this->variation_popup_toggle_text(); ?></a>
</div> 
